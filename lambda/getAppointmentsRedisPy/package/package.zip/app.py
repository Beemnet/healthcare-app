import boto3
import redis
import json
from botocore.credentials import RefreshableCredentials
from botocore.session import get_session

# Create a function to refresh IAM credentials
def refresh():
    sts_client = boto3.client('sts')
    creds = sts_client.assume_role(
        RoleArn='arn:aws:iam::381492119258:role/elasticache-iam-auth-app',
        RoleSessionName='elasticache-iam-auth-session'
    )['Credentials']
    return RefreshableCredentials.create_from_metadata(
        metadata=creds,
        refresh_using=refresh,
        method='sts-assume-role'
    )

def lambda_handler(event, context):
    # Replace these values with your cache endpoint
    elasticache_endpoint = "healthcare-appointments-mof3f0.serverless.eun1.cache.amazonaws.com"

    # Refresh IAM credentials
    creds = refresh()

    # Connect to ElastiCache Redis server
    redis_client = redis.Redis(
        host=elasticache_endpoint,
        port=6379,
        password=creds.token,
        ssl=True,
        ssl_cert_reqs="none"
    )

    # Fetch appointments from the Redis server based on the user's email
    user_email = event['email']
    appointments_key = f"appointments:{user_email}"
    appointments_json = redis_client.get(appointments_key)

    if appointments_json:
        appointments = json.loads(appointments_json)
        return {
            'statusCode': 200,
            'body': json.dumps({'appointments': appointments})
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'No appointments found for the user'})
        }
